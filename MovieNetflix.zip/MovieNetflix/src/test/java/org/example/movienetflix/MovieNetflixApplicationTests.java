package org.example.movienetflix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class MovieNetflixApplicationTests {

    @Test
    void contextLoads() {
    }


}
