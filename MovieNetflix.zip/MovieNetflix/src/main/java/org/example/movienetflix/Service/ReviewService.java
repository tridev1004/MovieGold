package org.example.movienetflix.Service;

import org.example.movienetflix.Entity.Movie;
import org.example.movienetflix.Entity.Reviews;
import org.example.movienetflix.Repo.MovieRepository;
import org.example.movienetflix.Repo.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ReviewService {
    @Autowired
    private ReviewRepository reviewRepository;
    @Autowired
    private MovieRepository movieRepository;
    @Autowired
    private MongoTemplate mongoTemplate;
    public Reviews CreateReview(String reviewBody, String ImdbId) {
        // Create a new Reviews object without setting the ID explicitly
        Reviews reviews = new Reviews(reviewBody);

        // Insert the review and let MongoDB generate the ID
        reviews = reviewRepository.insert(reviews);

        // Update the Movie document to include the review ID
        mongoTemplate.update(Movie.class)
                .matching(Criteria.where("imdbId").is(ImdbId))
                .apply(new Update().push("reviewIds").value(reviews.getReviewIds()))
                .first();

        return reviews;
    }
}
