package org.example.movienetflix.Controller;

import org.example.movienetflix.Entity.Movie;
import org.example.movienetflix.Service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/movies")
public class MovieController {
    @Autowired
    private MovieService movieService;
    @GetMapping
    public ResponseEntity<List<Movie>> GetAllMovies(){
        return  new ResponseEntity(movieService.Allmovies(),HttpStatus.OK);
    }

    @GetMapping("/{Id}")
    public ResponseEntity<Movie> GetMovie(@PathVariable("Id")String Id) {
        return new ResponseEntity<>(movieService.findTheID(Id),HttpStatus.OK);
    }

}
