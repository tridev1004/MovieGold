package org.example.movienetflix.Repo;

import org.bson.types.ObjectId;
import org.example.movienetflix.Entity.Reviews;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ReviewRepository extends MongoRepository<Reviews,ObjectId> {
}
