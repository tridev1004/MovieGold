import Hero from "./Hero";

export default function Home({ movies = [] }) {
  return (
    <div className="home">
      {movies.length > 0 ? (
        <Hero movies={movies} />
      ) : (
        <p>Loading movies...</p>
      )}
    </div>
  );
}
