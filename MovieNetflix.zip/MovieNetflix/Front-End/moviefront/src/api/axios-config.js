import axios from "axios";
export default axios.create({
    baseURL: 'https://58ce-2405-201-681e-90a4-6c73-b3f-9bf7-7aab.ngrok-free.app',
    headers: {
      'ngrok-skip-browser-warning': 'true'
    }
  });