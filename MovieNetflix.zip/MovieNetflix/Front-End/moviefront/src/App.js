import api from "./api/axios-config";
import { useState, useEffect } from 'react';
import { Routes, Route } from "react-router-dom";
import Layout from "./Components/Layout";
import Home from "./Components/Home";
import './App.css';
import Header from "./Components/Header";
import Trailer from "./Components/Trailer";
import Reviews from "./Components/Reviews";

function App() {
  const [movies, setMovies] = useState([]);  // Initialize as an empty array
  const [movie,setMovie]=useState();
  const [reviews , setReviews]=useState([]);
  const getMovies = async () => {
    try {
      const response = await api.get("/api/v1/movies");
      console.log(response.data);
      setMovies(response.data);
    } catch (err) {
      console.log(err);
    }
  };
  const getMovieData = async (movieId) => {
    try {
      const response = await api.get(`/api/v1/movies/${movieId}`);
      setMovie(response.data);
      setReviews(response.data.reviews || []);
    } catch (error) {
      console.error(error);
      setMovie(null);
      setReviews([]);
    }
  };
    useEffect(() => {
    getMovies();
  }, []);

  return (
    <div className='App'>
      <Header />
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home movies={movies} />} /> 
          <Route path="/Trailer/:ytTrailerId" element={<Trailer/>}></Route>  
          <Route path="/Reviews/:movieId" element={<Reviews  movie={movie}getMovieData={getMovieData} reviews={reviews} setReviews={setReviews}/>}/>
               </Route>
      </Routes>
      
    </div>
  );
}

export default App;
